<html>
    <head>
        <title>ee</title>
        <script src="js/jquery-1.4.min.js" type="text/javascript"></script>
        <script src="js/creditcard.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                alert("ÜÜ üü");
                
            });
        </script>

    </head>
    <body >
        <form id="myform" action="">

            <p style="margin-top: 10px;"><span style="color: #ff0000; margin-left: 20px;">Select credit card:</span>
                <select tabindex="11" id="CardType" style="margin-left: 10px;">
                    <option value="MasterCard">MasterCard</option>
                    <option value="Visa">Visa</option>
                </select>
                <span style="color: #ff0000; margin-left: 20px;">Enter number:
                    <input type="text" id="CardNumber" maxlength="24" size="24" style="margin-left: 10px;" />
                    <input type="submit" value="SEND" id="send" disabled/>
                    <button id="mybutton" type="button"  style="margin-left: 30px; color: #f00;">Check</button>
                </span></p>
        </form>

    </body>
</html>