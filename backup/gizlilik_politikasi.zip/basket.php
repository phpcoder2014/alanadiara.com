<?php
/* Create by ErdenGENCER  15.02.2010 Pazartesi */
session_start();
include_once('inc/xtpl.php');
include_once('inc/dbMysql.php');
include_once('inc/func.php');

$index = new XTemplate('temp/index.tpl');
$footer = new XTemplate('temp/footer.tpl');
$search = new XTemplate('temp/domain_search.tpl');
$main = new XTemplate('temp/basket.tpl');

$db=new dbMysql();


//$main->parse("main.saved");
//echo $_SERVER['HTTP_REFERER'];
$main->assign("alisveris_devam", $_SERVER['HTTP_REFERER']);
if(isset ($_SESSION['domBasket'])){
   $totalPrice=0;
   foreach ($_SESSION['domBasket'] as $val) {
      $rows=$db->get_row("select id,name,price from domain where id='".$val."' and orderid=0");
      $main->assign("domainID", $rows->id);
      $main->assign("domain_price", $rows->price." TL");
      $main->assign("domain_name", $rows->name."."."info");
      $totalPrice +=$rows->price;
      $main->parse("main.sepet.rows");
   }
   $main->assign("totalPrice", $totalPrice." TL");
   $main->parse("main.sepet.total");
   $main->parse("main.sepet");
}else {
    //no_record
    $main->parse("main.no_record");
}

$main->parse("main");
$index->assign("MAIN", $main->text("main"));

$search->parse("main");
$index->assign("domain_search", $search->text("main"));

$footer->parse("main");
$index->assign("FOOTER", $footer->text("main"));
$index->assign("HEADER", header_q());

$index->parse('main');
$index->out('main');
?>
