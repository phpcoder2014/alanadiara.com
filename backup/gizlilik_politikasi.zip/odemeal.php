<?php 
session_start();

include_once('inc/dbMysql.php');
include_once('inc/func.php');

if(!isset ($_SESSION['domBasket'])) {
    echo "Hata";
    exit ();
}
$db=new dbMysql();
$user_id=$_SESSION['net_users']['id'];
$billID=$db->insert("bill", array('user_id'=>$user_id,'firm_name'=>$firm_name,'firm_adress'=>$firm_adress,'tax_office'=>$tax_office,'tax_code'=>$tax_code));
$tprice=0;
foreach ($_SESSION['domBasket'] as $domID) {
    $res=$db->get_row("select price from domain where id='".$domID."' and orderid=0");
    if ($res->price) $tprice +=$res->price;
    else {
        echo "Seçtiğiniz domain alınmıştır.";
        exit ();
    }
}

//$tprice=1;
if (!is_numeric($tprice) || $tprice<=0) {
    echo "Ödeme sayfasında hata oluştu.";
    exit ();
}
if($action=="bank") {
    $order_result=PutOrder("bank",$tprice,$billID,0,$_POST['bank_info']);
    if(!$order_result) {
        echo "Ödeme sayfasında hata oluştu.";
        exit ();
    }else {
        $order_code=$order_result['ordercode'];
        $order_id=$order_result['orderid'];
        //echo "Sipariş numaranız <b>".$order_code."</b><br><br>Siparisininizin onaylanması için 3 (üç) gün içerisinde seçtiniz bankaya Ödemenizi iletmeniz gerekmektedir.";
        echo $order_code;
        sendOrderBankMail(array('bankid'=>$_POST['bank_info'],'code'=>$order_code,'email'=>$_SESSION['net_users']['email'],'name'=>$_SESSION['net_users']['name'],'tprice'=>$tprice));
    }

}else if($action=="mail_order") {
    $order_result=PutOrder("mail_order",$tprice,$billID,0,0);
    if(!$order_result) {
        echo "Ödeme sayfasında hata oluştu.";
        exit ();
    }else {
        $order_code=$order_result['ordercode'];
        $order_id=$order_result['orderid'];
        //echo "Sipariş numaranız <b>".$order_code."</b><br><br>Siparişinizin onaylanması için 3 (üç) gün içerisinde mailorder formunuzu imzalı ve kaşeli olarak ya da kimlik fotokopinizle birlikte <b>0224 224 95 20</b> no.'lu faksa iletmeniz gerekmektedir.";
        echo $order_code;
        sendOrderMailOrderMail(array('code'=>$order_code,'name'=>$_SESSION['net_users']['name'],'email'=>$_SESSION['net_users']['email'],'tprice'=>$tprice));
    }
}else if($action=="ccard") {

    include_once("inc/virtualpos.inc");
    $executement=ExecutePayment($_POST['ccardno'],$_POST['ccexpmonth'],$_POST['ccexpyear'],$_POST['cvv2'],$tprice);
    if ($executement['response']) {
        $order_result=PutOrder("ccard",$tprice,$billID,1,VP_CURRENT);

        if(!$order_result) {
            echo "Ödeme sayfasında hata oluştu.";
            exit ();
        }else {
            $order_code=$order_result['ordercode'];
            $order_id=$order_result['orderid'];
            $sql="INSERT INTO vpos (id, order_id, auth_id, trans_id, cost, ff_digits, lf_digits, time, orderin_id)
            VALUES (NULL, '".$executement['order_id']."', '".$executement['auth_id']."', '".$executement['trans_id']."', '".$tprice."', '".substr($_POST['ccardno'],0,4)."', '".substr($_POST['ccardno'],12)."', '".time()."', '".$order_id."')";
            //echo "Sipariş numaranız <b>".$order_code."</b><br><br>Siparişinizin onaylanması için 3 (üç) gün içerisinde mailorder formunuzu imzalı ve kaşeli olarak ya da kimlik fotokopinizle birlikte <b>0224 224 95 20</b> no.'lu faksa iletmeniz gerekmektedir.";
            $db->updateSql($sql);
            echo $order_code;
            sendOrderCcardMail(array('code'=>$order_code,'name'=>$_SESSION['net_users']['name'],'email'=>$_SESSION['net_users']['email'],'tprice'=>$tprice,'domain'=>$_SESSION['domBasket']));
            foreach ($_SESSION['domBasket'] as $valll) {
                gkupon(array('name'=>$_SESSION['net_users']['name'],'email'=>$_SESSION['net_users']['email'],'userID'=>$_SESSION['net_users']['id'],'domain'=>getDomainName($valll),'domID'=>$valll));
            }
             
        }
    }
    else {
        echo "Kart bakiyesi geçersiz ya da yanlış kart no girdiniz. Lütfen başka bir kredi kartı ile deneyiniz.";
        exit();
    }
    // echo $tprice."____".$_POST['ccardno'].",".$_POST['ccexpmonth'].",".$_POST['ccexpyear'].",".$_POST['cvv2'];
}

if(is_numeric($order_id)) {
    foreach ($_SESSION['domBasket'] as $domID) {
        $db->update("domain", array('orderid'=>$order_id),array('id'=>$domID));
    }
    unset ($_SESSION['domBasket']);
}
function PutOrder($payment_type,$total_cost,$billing,$status=0,$willpay=0) {

    if (!is_numeric($total_cost) || $total_cost<=0) return false;
    $db=new dbMysql();
    //$code=GetUniqueOrderCode();
    $code=time();

    switch ($payment_type) {
        case "ccard":
            $recieved_payment=$total_cost;
            $ordacttime=time();
            break;
        case "bank":
            $recieved_payment=0.00;
            $ordacttime=null;
            break;
        case "mail_order":
            $recieved_payment=0.00;
            $ordacttime=null;
            break;
    }
    $serialDomainID=serialize($_SESSION['domBasket']);
    $table=array('costumer_id'=>$_SESSION['net_users']['id'], 'order_code'=>$code, 'payment_type'=>$payment_type, 'total_cost'=>$total_cost,'status'=>$status, 'willpay'=>$willpay, 'billing'=>$billing, 'time'=>time(), 'act_time'=>$ordacttime, 'recieved_payment'=>$recieved_payment,'domainID'=>$serialDomainID);
    $orderID=$db->insert("orders", $table);
    //$sql="INSERT INTO orders () VALUES ('','".$_SESSION['net_users']['id']."','$code','$payment_type','$total_cost','$status','$willpay','$billing','".time()."', '$recieved_payment');";
    //$cmd=mysql_query($sql);
    if(!$orderID) {
        echo "Siparişiniz Kaydedilemedi.";
        return false;
    }
    else {
        return array("orderid"=>$orderID,"ordercode"=>$code);
    }
}
function ExecutePayment ($ccardno,$exp_m,$exp_y,$cvv2,$total) { //returns true or false

    if (strlen($exp_y)!=2) $exp_y=substr($exp_y,-2);
    if (strlen($exp_m)!=2) $exp_m=str_repeat("0",(2-strlen($exp_m))).$exp_m;

    $data="DATA=<?xml version=\"1.0\" encoding=\"ISO-8859-9\"?>
<CC5Request>
<Name>".VP_FORTIS_NAME."</Name>
<Password>".VP_FORTIS_PASSWORD."</Password>
<ClientId>".VP_FORTIS_CLIENTID."</ClientId>
<IPAddress>".$_SERVER['REMOTE_ADDR']."</IPAddress>
<Email></Email>
<Mode>".VP_FORTIS_MODE."</Mode>
<OrderId></OrderId>
<GroupId></GroupId>
<TransId></TransId>
<UserId></UserId>
<Type>".VP_FORTIS_TYPE."</Type>
<Number>$ccardno</Number>
<Expires>$exp_m/$exp_y</Expires>
<Cvv2Val>$cvv2</Cvv2Val>
<Total>$total</Total>
<Currency>".VP_FORTIS_CURRENCY."</Currency>
<Taksit></Taksit>
<BillTo>
<Name></Name>
<Street1></Street1>
<Street2></Street2>
<Street3></Street3>
<City></City>
<StateProv></StateProv>
<PostalCode></PostalCode>
<Country></Country>
<Company></Company>
<TelVoice></TelVoice>
</BillTo>
<ShipTo>
<Name></Name>
<Street1></Street1>
<Street2></Street2>
<Street3></Street3>
<City></City>
<StateProv></StateProv>
<PostalCode></PostalCode>
<Country></Country>
</ShipTo>
<Extra></Extra>
</CC5Request>";



    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_URL, VP_FORTIS_URL);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 90);
    $result = curl_exec($ch);
    curl_close($ch);


    $response_tag="Response";
    $posf = strpos (  $result, ("<" . $response_tag . ">") );
    $posl = strpos (  $result, ("</" . $response_tag . ">") ) ;
    $posf = $posf+ strlen($response_tag) +2 ;
    $Response = substr (  $result, $posf, $posl - $posf) ;

    $response_tag="OrderId";
    $posf = strpos (  $result, ("<" . $response_tag . ">") );
    $posl = strpos (  $result, ("</" . $response_tag . ">") ) ;
    $posf = $posf+ strlen($response_tag) +2 ;
    $OrderId = substr (  $result, $posf , $posl - $posf   ) ;

    $response_tag="AuthCode";
    $posf = strpos (  $result, "<" . $response_tag . ">" );
    $posl = strpos (  $result, "</" . $response_tag . ">" ) ;
    $posf = $posf+ strlen($response_tag) +2 ;
    $AuthCode = substr (  $result, $posf , $posl - $posf   ) ;

    $response_tag="TransId";
    $posf = strpos (  $result, "<" . $response_tag . ">" );
    $posl = strpos (  $result, "</" . $response_tag . ">" ) ;
    $posf = $posf+ strlen($response_tag) +2 ;
    $TransId = substr (  $result, $posf , $posl - $posf   ) ;

    if ($Response=="Approved") {
        return array("response"=>true,"order_id"=>$OrderId,"auth_id"=>$AuthCode,"trans_id"=>$TransId);
    }
    else {
        return array("response"=>false);
    }
}
?>
