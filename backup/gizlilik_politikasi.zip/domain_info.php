<?php /* Create by ErdenGENCER  15.02.2010 Pazartesi */
session_start();
include_once('inc/xtpl.php');
include_once('inc/dbMysql.php');
include_once('inc/func.php');

$index = new XTemplate('temp/index.tpl');
$footer = new XTemplate('temp/footer.tpl');

$search = new XTemplate('temp/domain_search.tpl');
$main = new XTemplate('temp/domain_info.tpl');
$main->assign("300x250", banner300X250());
$db=new dbMysql();

$db->updateSql("update domain set hit=hit+1 where id='".$id."'");

$data = file_get_contents("http://www.alexa.com/siteinfo/ok.net");//.$name);
$alexa = @explode("class=\"data down\">", $data);
$alexa = @explode("</a></div>", $alexa[1]);
$alexa = @explode("/>", $alexa[0]);
$page_rank = $alexa[1];

$alexa = @explode("alt=\"Turkey Flag\"/>", $data);
$alexa = @explode("</div>", $alexa[1]);
$TRpage_rank = $alexa[0];

$alexa = @explode("<div class=\"label\">Online Since", $data);
$alexa = @explode("<td class=\"end\">", $alexa[0]);
$Domain_Age = $alexa[1];

$alexa = @explode("id=\"contactinfo\">", $data);
$alexa = @explode("<div id=\"jigsaw\">", $alexa[1]);
$contact_info = $alexa[0];

$alexa = @explode("<h2>Search Traffic</h2>", $data);
$alexa = @explode("<p>", $alexa[1]);
$alexa = @explode("</p>", $alexa[2]);
$page_analiz = $alexa[0];


$main->assign("page_rank", $page_rank);
$main->assign("trpage_rank", $TRpage_rank);
$main->assign("Domain_Age", $Domain_Age);
$main->assign("page_contact_info", $contact_info);
$main->assign("page_analiz", $page_analiz);

$main->parse("main");
$index->assign("MAIN", $main->text("main"));

$search->parse("main");
$index->assign("domain_search", $search->text("main"));

$footer->parse("main");
$index->assign("FOOTER", $footer->text("main"));

$index->assign("HEADER", header_q());

$index->parse('main');
$index->out('main');
?>
