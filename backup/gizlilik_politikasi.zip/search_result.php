<?php
/* Create by ErdenGENCER  15.02.2010 Pazartesi */
session_start();
include_once('inc/xtpl.php');
include_once('inc/dbMysql.php');
include_once('inc/func.php');

$index = new XTemplate('temp/index.tpl');
$footer = new XTemplate('temp/footer.tpl');
$search = new XTemplate('temp/domain_search.tpl');
$main = new XTemplate('temp/search_result.tpl');

if($_SESSION['net_users']['id']=="") {
    $main->assign("usersession", "0");
}else $main->assign("usersession", "1");
$db=new dbMysql();
//print_r($_POST);
$kosul="";
$main->assign("arama_kaydet", $_SERVER['REQUEST_URI']);
$QUERY_STRING="";
foreach ($_GET as $key => $value) {
    if($key != "categori") {
        $QUERY_STRING .=$key.":'".$value."',\n";
    }else {
        $QUERY_STRING .="categori:".($categori).",\n";
    }
}
$main->assign("QUERY_STRING", $QUERY_STRING);
$_SESSION['arama']=array();
$_SESSION['arama']=$_GET;
//print_r($_SERVER);
if($btn=='Send') {
    //print_r($_POST);
    $spe="WHERE";
    $searchvalue=$searchvalue;
    if($searchvalue !="") {
    $kosul .=$spe." domain.name like '%".$searchvalue."%' ";
    }
    if($categori!="") {
        /*foreach ($_POST['categori'] as $cat) {
           $kosul .=" kategori.id in (6,7,8)";
        }*/
        $kosul .=" and kategori.id in (".implode(',', $categori).")";
    }
    if($order !="") {
        if($order==1){
            $order=" order by domain.price desc ";
            $main->assign("selected1", "selected");
        }else if($order==2){
            $order=" order by domain.price ";
            $main->assign("selected2", "selected");
        }else if($order==3){
            $order=" order by kategori.id desc ";
            $main->assign("selected3", "selected");
        }else if($order==4){
            $order=" order by kategori.id ";
            $main->assign("selected4", "selected");
        }else if($order==5){
            $order=" order by domain.price desc ";
            $main->assign("selected5", "selected");
        }else if($order==6){
            $order=" order by domain.hit ";
            $main->assign("selected6", "selected");
        }else {
            $order=" order by kategori.id ";
            $main->assign("selected1", "selected");
        }
    }else {
        $order=" order by kategori.id ";
    }
}else if($aramafiyat=="send") {
    //echo $fiyataralik;
    switch ($fiyataralik) {
        case 1:
            $kosul=" where (domain.price >=1 and domain.price<=5) ";
            $order=" order by domain.price ";
            break;
        case 2:
            $kosul=" where (domain.price >=6 and domain.price<=10) ";
            $order=" order by domain.price ";
            break;
        case 3:
            $kosul=" where (domain.price >=11 and domain.price<=15) ";
            $order=" order by domain.price ";
            break;
        case 4:
            $kosul=" where (domain.price >=16 and domain.price<=20) ";
            $order=" order by domain.price ";
            break;
        case 5:
            $kosul=" where (domain.price >=21 and domain.price<=90) ";
            $order=" order by domain.price ";
            break;

        default:
            break;
    }
}
$search->assign("searchvalue", $searchvalue);
if($list=="tum"){
    $kosul="";
}
//echo $query="select * from domain $kosul limit 10";
$query="SELECT
kategori.name AS catname,
kategori.id AS catid,
domain.id,
domain.name,
domain.orderid,
domain.price
FROM
domain
Inner Join dom_cat ON dom_cat.id_dom = domain.id
Inner Join kategori ON kategori.id = dom_cat.id_cat

$kosul
group by domain.name
$order
";
$num=$db->num_rows($query);
$main->assign("arama_num", $num);
if($num>0) {
    $main->assign("topnum", ceil($num/10));
    $sres=$db->get_rows($query." limit 10");
    $i=1;
    foreach ($sres as $srow) {
        $main->assign("domainID", $srow->id);
        $main->assign("domain_cat", getDomainCat($srow->id,$categori));

        $main->assign("domain_price", $srow->price." TL");
        $main->assign("domain_name", $srow->name.".info");
        ($i%2==0)?$main->assign("bgcolor", "#f1f1f1"):$main->assign("bgcolor", "#ffffff");
        if($srow->orderid==0){
           $main->parse("main.result.search_rows.al_bakam");
        }else {
            
        }
        $main->parse("main.result.search_rows");
        $i++;
    }
    $main->parse("main.result");

}else {
    $main->parse("main.kayit_yok");
}


// START SAĞ

$main->assign("searchvalue", $searchvalue);
$cres=$db->get_rows("select * from kategori order by id");
$i=1;
foreach ($cres as $val) {
    $main->assign("cat_name", $val->name);
    $main->assign("catID", $val->id);
    if($categori != "") {
        (in_array($val->id, $categori))?$main->assign("checked", "checked"):$main->assign("checked", " ");
    }
    
    $main->parse("main.aramaSag.cat.rows.rows1");
    ($i%2!=0)?$main->parse("main.aramaSag.cat.rows.rows2"):"";
    ($i%2==0)?$main->parse("main.aramaSag.cat.rows"):"";
    $i++;
}
($i%2==0)?$main->parse("main.aramaSag.cat.rows"):"";

$main->parse("main.aramaSag.cat");

if($_SESSION['net_users']['id']!="") {
    $save_sql="select * from save_search where id_user='".$_SESSION['net_users']['id']."' order by time desc";
    $s_num=$db->num_rows($save_sql);
    if($s_num > 0) {
        $s_res=$db->get_rows($save_sql);
        foreach ($s_res as $s_val) {
            $main->assign("sil_link", $s_val->id);
            $main->assign("save_link", $s_val->search);
            $main->assign("save_name", $s_val->name);
            $main->parse("main.aramaSag.save_search");
        }
    }else {
        
    }
}



$main->parse("main.aramaSag");
// END SAĞ

$main->parse("main");
$index->assign("MAIN", $main->text("main"));


$search->parse("main");
$index->assign("domain_search", $search->text("main"));

$footer->parse("main");
$index->assign("FOOTER", $footer->text("main"));
$index->assign("HEADER", header_q());

$index->parse('main');
$index->out('main');
?>
